-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ebanking
-- ------------------------------------------------------
-- Server version	5.6.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accountreceiver`
--

DROP TABLE IF EXISTS `accountreceiver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accountreceiver` (
  `idAccountReceiver` int(11) NOT NULL AUTO_INCREMENT,
  `accountReceiver` varchar(45) NOT NULL,
  `idBank` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`idAccountReceiver`),
  KEY `fk_accountReceiver_bank1_idx` (`idBank`),
  CONSTRAINT `fk_accountReceiver_bank1` FOREIGN KEY (`idBank`) REFERENCES `bank` (`idBank`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accountreceiver`
--

LOCK TABLES `accountreceiver` WRITE;
/*!40000 ALTER TABLE `accountreceiver` DISABLE KEYS */;
INSERT INTO `accountreceiver` VALUES (1,'abc',1,1);
/*!40000 ALTER TABLE `accountreceiver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `atm`
--

DROP TABLE IF EXISTS `atm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `atm` (
  `idATM` int(11) NOT NULL AUTO_INCREMENT,
  `location` varchar(45) NOT NULL,
  `idBank` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`idATM`),
  KEY `fk_ATM_Bank1_idx` (`idBank`),
  CONSTRAINT `fk_ATM_Bank1` FOREIGN KEY (`idBank`) REFERENCES `bank` (`idBank`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `atm`
--

LOCK TABLES `atm` WRITE;
/*!40000 ALTER TABLE `atm` DISABLE KEYS */;
/*!40000 ALTER TABLE `atm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bank`
--

DROP TABLE IF EXISTS `bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bank` (
  `idBank` int(11) NOT NULL AUTO_INCREMENT,
  `bankName` varchar(100) NOT NULL,
  `bankAddress` varchar(100) NOT NULL,
  `bankMail` char(45) NOT NULL,
  `bankPhone` char(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`idBank`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank`
--

LOCK TABLES `bank` WRITE;
/*!40000 ALTER TABLE `bank` DISABLE KEYS */;
INSERT INTO `bank` VALUES (1,'BkerBank','Tầng 20 keangnam','bkerbank@fpt.com.vn','19000000',1);
/*!40000 ALTER TABLE `bank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bankaccount`
--

DROP TABLE IF EXISTS `bankaccount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bankaccount` (
  `idBankAccount` int(11) NOT NULL AUTO_INCREMENT,
  `accountNumber` varchar(45) NOT NULL,
  `cardNumber` char(20) NOT NULL,
  `openedDate` varchar(45) NOT NULL,
  `balance` double NOT NULL,
  `ebanking` tinyint(1) NOT NULL,
  `idMoneyType` int(11) NOT NULL,
  `idCustomerAccount` int(11) NOT NULL,
  `idBankAccountType` int(11) NOT NULL,
  `idBank` int(11) NOT NULL,
  PRIMARY KEY (`idBankAccount`),
  KEY `fk_BankAccount_CustomerAccount_idx` (`idCustomerAccount`),
  KEY `fk_BankAccount_BankAccountType1_idx` (`idBankAccountType`),
  KEY `fk_BankAccount_Bank1_idx` (`idBank`),
  KEY `fk_BankAccount_MoneyType1_idx` (`idMoneyType`),
  CONSTRAINT `fk_BankAccount_Bank1` FOREIGN KEY (`idBank`) REFERENCES `bank` (`idBank`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_BankAccount_BankAccountType1` FOREIGN KEY (`idBankAccountType`) REFERENCES `bankaccounttype` (`idBankAccountType`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_BankAccount_CustomerAccount` FOREIGN KEY (`idCustomerAccount`) REFERENCES `customeraccount` (`idCustomerAccount`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_BankAccount_MoneyType1` FOREIGN KEY (`idMoneyType`) REFERENCES `currency` (`idCurrency`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bankaccount`
--

LOCK TABLES `bankaccount` WRITE;
/*!40000 ALTER TABLE `bankaccount` DISABLE KEYS */;
INSERT INTO `bankaccount` VALUES (1,'711A68126413','1111111100002222','2015-08-01',1000000,1,1,1,1,1),(2,'ahahanan','08007687686','2015-01-01',100000,1,2,1,2,1);
/*!40000 ALTER TABLE `bankaccount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bankaccounttype`
--

DROP TABLE IF EXISTS `bankaccounttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bankaccounttype` (
  `idBankAccountType` int(11) NOT NULL AUTO_INCREMENT,
  `BankAccountType` varchar(45) NOT NULL,
  `limitedBorrow` double NOT NULL,
  PRIMARY KEY (`idBankAccountType`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bankaccounttype`
--

LOCK TABLES `bankaccounttype` WRITE;
/*!40000 ALTER TABLE `bankaccounttype` DISABLE KEYS */;
INSERT INTO `bankaccounttype` VALUES (1,'Gold',100000),(2,'Sliver',80000);
/*!40000 ALTER TABLE `bankaccounttype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency`
--

DROP TABLE IF EXISTS `currency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currency` (
  `idCurrency` int(11) NOT NULL,
  `currencyName` varchar(45) NOT NULL,
  `rate` double NOT NULL COMMENT 'rate so với việt nam đồng',
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`idCurrency`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currency`
--

LOCK TABLES `currency` WRITE;
/*!40000 ALTER TABLE `currency` DISABLE KEYS */;
INSERT INTO `currency` VALUES (1,'Đồng',1,1),(2,'Đô la',20000,1);
/*!40000 ALTER TABLE `currency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customeraccount`
--

DROP TABLE IF EXISTS `customeraccount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customeraccount` (
  `idCustomerAccount` int(11) NOT NULL AUTO_INCREMENT,
  `userName` char(20) NOT NULL,
  `password` char(20) NOT NULL,
  `name` varchar(45) NOT NULL,
  `idCard` char(12) NOT NULL,
  `birthDay` date NOT NULL,
  `address` varchar(100) NOT NULL,
  `phone` char(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`idCustomerAccount`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customeraccount`
--

LOCK TABLES `customeraccount` WRITE;
/*!40000 ALTER TABLE `customeraccount` DISABLE KEYS */;
INSERT INTO `customeraccount` VALUES (1,'tinhpt94','123','Phạm Trung Tính','135662780','1994-12-30','Ngõ 190 Nguyễn Trãi','0972426521',1);
/*!40000 ALTER TABLE `customeraccount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `onlineborrow`
--

DROP TABLE IF EXISTS `onlineborrow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `onlineborrow` (
  `idOnlineBorrow` int(11) NOT NULL AUTO_INCREMENT,
  `amount` double NOT NULL,
  `term` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `idBankAccount` int(11) NOT NULL,
  `transaction_idTransaction` int(11) NOT NULL,
  PRIMARY KEY (`idOnlineBorrow`),
  KEY `fk_onlineborrow_bankaccount1_idx` (`idBankAccount`),
  KEY `fk_onlineborrow_transaction1_idx` (`transaction_idTransaction`),
  CONSTRAINT `fk_onlineborrow_bankaccount1` FOREIGN KEY (`idBankAccount`) REFERENCES `bankaccount` (`idBankAccount`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_onlineborrow_transaction1` FOREIGN KEY (`transaction_idTransaction`) REFERENCES `transaction` (`idTransaction`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `onlineborrow`
--

LOCK TABLES `onlineborrow` WRITE;
/*!40000 ALTER TABLE `onlineborrow` DISABLE KEYS */;
/*!40000 ALTER TABLE `onlineborrow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction`
--

DROP TABLE IF EXISTS `transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction` (
  `idTransaction` int(11) NOT NULL AUTO_INCREMENT,
  `transactionDate` date NOT NULL,
  `transactionContent` varchar(45) NOT NULL,
  `amount` double NOT NULL,
  `status` varchar(20) NOT NULL,
  `idTransactionType` int(11) NOT NULL,
  `idBankAccount` int(11) NOT NULL,
  `idAccountReceiver` int(11) NOT NULL,
  PRIMARY KEY (`idTransaction`),
  KEY `fk_Transaction_TransactionType1_idx` (`idTransactionType`),
  KEY `fk_Transaction_BankAccount1_idx` (`idBankAccount`),
  KEY `fk_transaction_accountReceiver1_idx` (`idAccountReceiver`),
  CONSTRAINT `fk_Transaction_BankAccount1` FOREIGN KEY (`idBankAccount`) REFERENCES `bankaccount` (`idBankAccount`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Transaction_TransactionType1` FOREIGN KEY (`idTransactionType`) REFERENCES `transactiontype` (`idTransactionType`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_transaction_accountReceiver1` FOREIGN KEY (`idAccountReceiver`) REFERENCES `accountreceiver` (`idAccountReceiver`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction`
--

LOCK TABLES `transaction` WRITE;
/*!40000 ALTER TABLE `transaction` DISABLE KEYS */;
INSERT INTO `transaction` VALUES (5,'2015-11-23','chuy?n ti?n',50000,'success',1,1,1);
/*!40000 ALTER TABLE `transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactiontype`
--

DROP TABLE IF EXISTS `transactiontype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactiontype` (
  `idTransactionType` int(11) NOT NULL AUTO_INCREMENT,
  `transactionType` varchar(45) NOT NULL,
  `transferType` tinyint(1) NOT NULL COMMENT 'transferType dùng để kiểm tra xem có phải dịch vụ thanh toán hóa đơn không',
  `idServiceAccount` int(11) NOT NULL,
  PRIMARY KEY (`idTransactionType`),
  KEY `fk_transactiontype_bankaccount1_idx` (`idServiceAccount`),
  CONSTRAINT `fk_transactiontype_bankaccount1` FOREIGN KEY (`idServiceAccount`) REFERENCES `bankaccount` (`idBankAccount`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactiontype`
--

LOCK TABLES `transactiontype` WRITE;
/*!40000 ALTER TABLE `transactiontype` DISABLE KEYS */;
INSERT INTO `transactiontype` VALUES (1,'Chuyển khoản trong ngân hàng',0,1);
/*!40000 ALTER TABLE `transactiontype` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-11-24  0:30:05
